var conn = new WebIM.connection({
	https: WebIM.config.https,
	url: WebIM.config.xmppURL,
	isAutoLogin: WebIM.config.isAutoLogin,
	isMultiLoginSessions: WebIM.config.isMultiLoginSessions
});
var easelogin = function (username,password){
	var options = { 
		apiUrl: WebIM.config.apiURL,
		user: username,
		pwd: password,
		appKey: WebIM.config.appkey
	};
	conn.open(options);
};
var easelogout =  function (){
	conn.close();
};