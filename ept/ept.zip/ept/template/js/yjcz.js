/*页脚/取消操作js*/
function zhuye(e){
	$(e).children("img").attr("src","../../template/imgs/zydj.png");
	var yhlx = localStorage.getItem("yhlx")||"";//01 管理员 02 普通用户 03 部级用户 04 省级用户
	if(yhlx =="" ||yhlx == "02"){
		window.location.href="../main_ptyh.html";
	}else{
		window.location.href="../main.html";	
	}
	
	
}
/**返回主页*/
function fhzy(e){
	$(e).children("img").attr("src","../../template/imgs/fhdj.png");
	var yhlx = localStorage.getItem("yhlx")||"";//01 管理员 02 普通用户 03 部级用户 04 省级用户
	if(yhlx =="" ||yhlx == "02"){
		window.location.href="../main_ptyh.html";
	}else{
		window.location.href="../main.html";	
	}
}
function fanhui(e){
	$(e).children("img").attr("src","../../template/imgs/fhdj.png");
}
function qx(r){
	document.getElementById(r).reset(); 
	//$(this).blur();
}
//主页消息
function z_xx(){
	window.location.href="xiaoxi/xx.html";
}
//主页通讯录
function z_txl(){
	window.location.href="tongxunlu/txl.html";	
}
//主页设置
function z_sz(){
	window.location.href="shezhi/sz.html";	
}
/** 
* 解析URL中的参数 
* @param {url路径} string 
* @returns {返回object<key,value>}  
*/  
$.getUrlParam = function(string) { 
var obj = new Object(); 
if (string.indexOf("?") != -1) {  
    var string = string.substr(string.indexOf("?") + 1);  
    var strs = string.split("&");  
    for (var i = 0; i < strs.length; i++) {  
        var tempArr = strs[i].split("="); 
//        if(tempArr[1].indexOf("#")!=-1){
//        	tempArr[1] = tempArr[1].replace("#","");
//        	obj[tempArr[0]] = decodeURI(tempArr[1]);  
//        }else{
//        	obj[tempArr[0]] = decodeURI(tempArr[1]);  
//        }
        obj[tempArr[0]] = decodeURI(tempArr[1]);  
    }  
}  
return obj;  
}
/**
 * 查询没有结果时数据展示
 * @param e
 */
function nodatashow(e){
	$("#"+e).html("<div style='text-align:center;'>没有数据</div>");
}
/**
 * 验证手机号
 */
function validatePhone(e){
	var patt1=new RegExp("^1(3|4|5|7|8)[0-9]{9}$");
	return patt1.test(e);
}

/**
 * 验证邮箱
 */
function validateEmail(e){
	var patt1=new RegExp("^[A-Za-z0-9_]+@[A-Za-z0-9_]+(\.[A-Za-z]{2,})+$");
	return patt1.test(e);
}

